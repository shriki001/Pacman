Paste the 2 DLL files to thows Directory:
C:\Windows\System32
C:\Windows\SysWOW64
just Copy & Paste